package com.example.myfirstapp.server_communication

data class Post(
    val id: Int,
    val title: String,
    val body: String
)